import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Test;

/** 
 *  You can use this file (and others) to test your
 *  implementation.
 */

public class GameTest {

	// Tests setting the color of the chip in various slots
    @Test
    public void testSetChipColor() {
    	Chip[][] board = new Chip[7][6];
    	board[0][0] = new Chip(700, 600, Color.BLACK);
    	board[0][0].setPx(0 * 75 + 75);
		board[0][0].setPy(0 * 75 + 75);
		board[1][0] = new Chip(700, 600, Color.BLACK);
		board[1][0].setPx(1 * 75 + 75);
		board[1][0].setPy(0 * 75 + 75);
		board[0][1] = new Chip(700, 600, Color.BLACK);
		board[0][1].setPx(0 * 75 + 75);
		board[0][1].setPy(1 * 75 + 75);

    	assertEquals("x 0, 0", 75, board[0][0].getPx());
    	assertEquals("y 0, 0", 75, board[0][0].getPy());
    	assertEquals("x 1, 0", 150, board[1][0].getPx());
    	assertEquals("y 1, 0", 75, board[1][0].getPy());
    	assertEquals("x 0, 1", 75, board[0][1].getPx());
    	assertEquals("y 0, 1", 150, board[0][1].getPy());
    }
    
    //Tests getting four chips of one color in a row in the horizontal direction
    @Test
    public void testHorizontalFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(1, 5);
		chip1.setColor(Color.BLACK);
		Chip chip2 = board.getChip(2, 5);
		chip2.setColor(Color.BLACK);
		Chip chip3 = board.getChip(3, 5);
		chip3.setColor(Color.BLACK);
		Chip chip4 = board.getChip(4, 5);
		chip4.setColor(Color.BLACK);
		
		assertEquals("Four 1,5", true, board.hasFour(1, 5, Color.BLACK));
		assertEquals("Four 2,5", true, board.hasFour(2, 5, Color.BLACK));
		assertEquals("Four 3,5", true, board.hasFour(3, 5, Color.BLACK));
		assertEquals("Four 4,5", true, board.hasFour(4, 5, Color.BLACK));
    }
    
  //Tests having four chips on the same horizontal, but not in a row. Should identify that is not four in a row
    @Test
    public void testHorizontalNotFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(1, 5);
		chip1.setColor(Color.BLACK);
		Chip chip2 = board.getChip(2, 5);
		chip2.setColor(Color.WHITE);
		Chip chip3 = board.getChip(3, 5);
		chip3.setColor(Color.BLACK);
		Chip chip4 = board.getChip(4, 5);
		chip4.setColor(Color.BLACK);
		Chip chip5 = board.getChip(5, 5);
		chip5.setColor(Color.BLACK);
		
		assertEquals("Four 1,5", false, board.hasFour(1, 5, Color.BLACK));
		assertEquals("Four 5,5", false, board.hasFour(5, 5, Color.BLACK));
		
		Chip chip6 = board.getChip(6, 5);
		chip6.setColor(Color.BLACK);
		assertEquals("Four 6,5", true, board.hasFour(6, 5, Color.BLACK));
    }
    
    //Tests getting four chips of one color in a row in the vertical direction
    @Test
    public void testVerticalFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(3, 5);
		chip1.setColor(Color.BLACK);
		assertEquals("Four 3,5", false, board.hasFour(3, 5, Color.BLACK));
		
		Chip chip2 = board.getChip(3, 4);
		chip2.setColor(Color.BLACK);
		assertEquals("Four 3,4", false, board.hasFour(3, 4, Color.BLACK));
		
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		assertEquals("Four 3,3", false, board.hasFour(3, 3, Color.BLACK));
		
		Chip chip4 = board.getChip(3, 2);
		chip4.setColor(Color.BLACK);
		assertEquals("Four 3,2", true, board.hasFour(3, 2, Color.BLACK));
    }
    
  //Tests having four chips in the same column, but not in a row. Should identify that is not four in a row
    @Test
    public void testVerticalNotFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(3, 5);
		chip1.setColor(Color.BLACK);
		Chip chip2 = board.getChip(3, 4);
		chip2.setColor(Color.BLACK);
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		Chip chip4 = board.getChip(3, 2);
		chip4.setColor(Color.WHITE);
		Chip chip5 = board.getChip(3, 1);
		chip5.setColor(Color.BLACK);
		assertEquals("Four 3,1", false, board.hasFour(3, 1, Color.BLACK));
    }
    
    //Tests getting four chips of one color in a row in the forward diagonal direction
    @Test
    public void testForwardDiagFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(1, 5);
		chip1.setColor(Color.BLACK);
		assertEquals("Four 1,5", false, board.hasFour(1, 5, Color.BLACK));
		
		Chip chip2 = board.getChip(2, 4);
		chip2.setColor(Color.BLACK);
		assertEquals("Four 2,4", false, board.hasFour(2, 4, Color.BLACK));
		
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		assertEquals("Four 3,3", false, board.hasFour(3, 3, Color.BLACK));
		
		Chip chip4 = board.getChip(4, 2);
		chip4.setColor(Color.BLACK);
		assertEquals("Four 4,2", true, board.hasFour(4, 2, Color.BLACK));
    }
    
  //Tests having four chips on the same diagonal, but not in a row. Should identify that is not four in a row
    @Test
    public void testForwardDiagNotFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(1, 5);
		chip1.setColor(Color.BLACK);
		Chip chip2 = board.getChip(2, 4);
		chip2.setColor(Color.BLACK);
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		Chip chip4 = board.getChip(4, 2);
		chip4.setColor(Color.WHITE);
		Chip chip5 = board.getChip(5, 1);
		chip5.setColor(Color.BLACK);
		assertEquals("Four 5,1", false, board.hasFour(5, 1, Color.BLACK));
    }
    
    //Tests getting four chips of one color in a row in the backwards diagonal direction
    @Test
    public void testBackDiagFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(5, 5);
		chip1.setColor(Color.BLACK);
		assertEquals("Four 5,5", false, board.hasFour(5, 5, Color.BLACK));
		
		Chip chip2 = board.getChip(4, 4);
		chip2.setColor(Color.BLACK);
		assertEquals("Four 4,4", false, board.hasFour(4, 4, Color.BLACK));
		
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		assertEquals("Four 3,3", false, board.hasFour(3, 3, Color.BLACK));
		
		Chip chip4 = board.getChip(2, 2);
		chip4.setColor(Color.BLACK);
		assertEquals("Four 2,2", true, board.hasFour(2, 2, Color.BLACK));
    }
    
  //Tests having four chips on the same diagonal, but not in a row. Should identify that is not four in a row
    @Test
    public void testBackDiagNotFour() {
    	GameVisual board = new GameVisual();
    	Chip chip1 = board.getChip(5, 5);
		chip1.setColor(Color.BLACK);
		Chip chip2 = board.getChip(4, 4);
		chip2.setColor(Color.WHITE);
		Chip chip3 = board.getChip(3, 3);
		chip3.setColor(Color.BLACK);
		Chip chip4 = board.getChip(2, 2);
		chip4.setColor(Color.BLACK);
		Chip chip5 = board.getChip(1, 1);
		chip5.setColor(Color.BLACK);
		assertEquals("Four 1,1", false, board.hasFour(1, 1, Color.BLACK));
    }

}
