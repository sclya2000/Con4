import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.Reader;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 * GameBoard
 * 
 * This class holds the primary game logic for how different objects interact with one another. 
 */
@SuppressWarnings("serial")
public class GameBoard extends JPanel {
	// Stores each move that is made
	LinkedList<String> moves = new LinkedList<String>();

    // The state of the game logic
    private GameVisual board;

    public boolean playing = false; // whether the game is running 
    private JLabel status; // Current status text, i.e. "Running..."

    // Game constants
    public static final int COURT_WIDTH = 750;
    public static final int COURT_HEIGHT = 700;

    // Update interval for timer, in milliseconds
    public static final int INTERVAL = 35;
    
    // Stores the value that determines if there is a winner or not
    private Boolean hasWinner = false;
    
    // Stores the value that determines the current player
    private Boolean currentPlayer = true;

    
    public GameBoard(JLabel status) {
    	
        // creates border around the court area, JComponent method
        setBorder(BorderFactory.createLineBorder(Color.BLACK));

        // The timer is an object which triggers an action periodically with the given INTERVAL. We
        // register an ActionListener with this timer, whose actionPerformed() method is called each
        // time the timer triggers. We define a helper method called tick() that actually does
        // everything that should be done in a single timestep.
        Timer timer = new Timer(INTERVAL, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tick();
            }
        });
        timer.start(); 

        // This mouse listener allows the user to drop a chip into the column that they click in
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
            	Color c;
            	if (currentPlayer) {
            		c = Color.RED;
            	} else {
            		c = Color.BLUE;
            	}
                Point p = e.getPoint();
        		int x = (int) Math.round(p.x/100);
        		int y = board.findSlot(x);
	        	if (playing) {
	        		if (y != -1) {
	        			String s = "" + x + y;
		                moves.add(s);
	        			
		        		Chip newChip = board.getChip(x, y);
		        		newChip.setColor(c);
		                repaint();
		                if (board.hasFour(x, y, c)){
		                	hasWinner = true;
		                }
		                currentPlayer = !currentPlayer;
		                String player;
		                if (currentPlayer) {
		                	player = "Red";
		                } else {
		                	player = "Blue";
		                }
		                status.setText(player + "'s Turn");
		                
	        		}
	            }
            }
        });

        this.status = status;
    
    }

    /**
     * (Re-)set the game to its initial state.
     */
    public void reset() {
    	board = new GameVisual();
    	repaint();

        playing = true;
        currentPlayer = true;
        hasWinner = false;
        status.setText("Red's Turn");
    }

    /**
     * This method is called every time the timer defined in the constructor triggers.
     */
    void tick() {
        if (playing) {
            if (hasWinner) {
            	String player;
                if (!currentPlayer) {
                	player = "Red";
                } else {
                	player = "Blue";
                }
                status.setText(player + " Has Won!");
                playing = false;
            }
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        board.drawBoard(g);
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(COURT_WIDTH, COURT_HEIGHT);
    }
    
    
    /**
     * Stores the information of the game which contains the state of the board and the 
     * player whose turn it is to move as a String. The String consists of ints that represent
     * the current player and the color of each slot on the board.  
     *
     * @return String of ints that represents the player whose turn it is and the position of all of the chips
     * @throws IOException if error while reading
     */
    public String saveGame() throws IOException {
    	int current;
    	if (currentPlayer) {
    		current = 0;
    	} else {
    		current = 1;
    	}
    	StringBuilder state = new StringBuilder();
    	state.append(current);
        int[][] boardState = board.getBoardState();
        for (int i = 0; i < boardState.length; i++) {
        	for (int j = 0; j < boardState[i].length; j++) {
        		state.append(boardState[i][j]);
        	}
        }
        return state.toString();
    }
    
    /**
     * Takes in a string of ints that stores the information of the previously saved game which contains
     * the state of the board and the player whose turn it is to move. It updates the board to 
     * the position and turn of the saved game.
     *
     * @param state The state of the saved game
     * @throws IOException if error while reading
     */
    public void loadGame(String state) throws IOException {
    	int current = Character.getNumericValue(state.charAt(0));
    	if (current == 0) {
    		this.currentPlayer = true;
    	} else {
    		this.currentPlayer = false;
    	}
    	
    	int[][] boardState = new int[7][6];
    	int c = 1;
    	String s = "" + current;
    	for (int i = 0;  i < boardState.length; i++) {
    		for (int j = 0; j < boardState[0].length; j++) {
    			boardState[i][j] = Character.getNumericValue(state.charAt(c));
    			s += Character.getNumericValue(state.charAt(c));
    			c++;
    		}
    	}
        board.setBoardState(boardState);
    }
    
    public void undo() {
    	if (playing) {
	    	this.currentPlayer = !currentPlayer;
	    	String player;
	        if (currentPlayer) {
	        	player = "Red";
	        } else {
	        	player = "Blue";
	        }
	        status.setText(player + "'s Turn");
	    	String s = moves.removeLast();
	    	int x = Integer.parseInt(s.substring(0,1));
	    	int y = Integer.parseInt(s.substring(1));
	    	Chip temp = board.getChip(x, y);
			temp.setColor(Color.WHITE);
			repaint();
    	}
    }
}