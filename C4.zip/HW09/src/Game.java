// imports necessary libraries for Java swing
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;

/**
 * Game Main class that specifies the frame and widgets of the GUI
 */
public class Game implements Runnable {
    public void run() {
        // NOTE : recall that the 'final' keyword notes immutability even for local variables.

        // Top-level frame in which game components live
        // Be sure to change "TOP LEVEL FRAME" to the name of your game
        final JFrame frame = new JFrame("TOP LEVEL FRAME");
        frame.setLocation(300, 300);

        // Status panel
        final JPanel status_panel = new JPanel();
        frame.add(status_panel, BorderLayout.SOUTH);
        final JLabel status = new JLabel("Running...");
        status_panel.add(status);

        // Main playing area
        final GameBoard court = new GameBoard(status);
        frame.add(court, BorderLayout.CENTER);

        // Reset button
        final JPanel control_panel = new JPanel();
        frame.add(control_panel, BorderLayout.NORTH);

        // Note here that when we add an action listener to the reset button, we define it as an
        // anonymous inner class that is an instance of ActionListener with its actionPerformed()
        // method overridden. When the button is pressed, actionPerformed() will be called.
        final JButton reset = new JButton("Reset");
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                court.reset();
            }
        });
        control_panel.add(reset);

        // Put the frame on the screen
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        // Start game
        court.reset();
        
     /* Undo button:
      * Undoes the last move and switches the current player to the one who made the undone move
      * to allow them to redo their move
      */
        final JButton undo = new JButton("Undo Last Move");
        undo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	court.undo();
            }
        });
        control_panel.add(undo);

     /* Load button: 
      * Loads the most recently saved version of the game 
      */
        final JButton load = new JButton("Load Saved Game");
        load.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {				
            	try {
					BufferedReader reader = new BufferedReader(new FileReader("files/GameState.txt"));
					court.reset();
					court.loadGame(reader.readLine());
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
            }
        });
        control_panel.add(load);
        

     /* Save button: 
      * Saves the current position of the game and the player whose turn it is
      */
        final JButton save = new JButton("Save Game");
        save.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
					try {
						String gameData = court.saveGame();
						File file = new File("files/GameState.txt");
						file.getParentFile().mkdirs();
						FileWriter fw = new FileWriter(file);
						BufferedWriter bw = new BufferedWriter(fw);
						bw.write(gameData);
						bw.close();
					} catch (IOException ioe) {
						ioe.printStackTrace();
					}
            	
            }
        });
        control_panel.add(save);
    }

    /**
     * Main method run to start and run the game. Initializes the GUI elements specified in Game and
     * runs it. IMPORTANT: Do NOT delete! You MUST include this in your final submission.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new CFGame());
    }
}