import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class GameGrid {
	private Chip[][] board = new Chip[7][6];
	public static final int COURT_WIDTH = 900;
    public static final int COURT_HEIGHT = 800;
	
	public GameGrid() {
		
	}
	
	public void drawBoard(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillRect(450, 400, COURT_WIDTH, COURT_HEIGHT);
		Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        for (int i = 0; i < board.length; i++) {
        	for (int j = 0; j < board[i].length; j++) {
        		int xCoor = i * 50 + 25;
        		int yCoor = j * 50 + 50;
        		g2d.fillOval(xCoor, yCoor, 50, 50);
        	}
        }
    }
	
	public int findSlot(int x) {
		int y = 6;
		for (int i = y; i >= 0; i--) {
			if (board[x][y] == null) {
				return y;
			}
		}
		return -1;
	}
	
	public void drawChip(int x, int y, Color c, Graphics g) {
		g.setColor(c);
		g.fillOval(x * 75 + 75, y * 75 + 75, 50, 50);
	}
}
