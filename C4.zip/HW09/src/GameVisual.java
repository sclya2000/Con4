import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.awt.Graphics;
import java.io.IOException;

/**
 * GameVisual
 * 
 * This class holds the code for drawing and displaying the board and the chips.
 * It also contains the methods for checking if a player's move gives them four chips in a row.
 */
public class GameVisual {
	private Chip[][] board;
	public static final int COURT_WIDTH = 750;
    public static final int COURT_HEIGHT = 700;
	
    // Constructs a GameVisual and makes each slot of the board a white chip that acts as a "blank" slot
	public GameVisual() {
		board = new Chip[7][6];
		for (int i = 0; i < board.length; i++) {
        	for (int j = 0; j < board[i].length; j++) {
        			board[i][j] = new Chip(COURT_WIDTH, COURT_HEIGHT, Color.WHITE);
        			board[i][j].setPx(i * 100 + 50);
        			board[i][j].setPy(j * 100 + 50);
        	}
        }
	}
	
   /* Draws the game board and the color of each slot on the board. White slots are empty and 
	* colored slots represent slots that contain chips
	*/
	public void drawBoard(Graphics g) {
		g.setColor(Color.YELLOW);
		g.fillRect(0, 0, COURT_WIDTH, COURT_HEIGHT);
		
        for (int i = 0; i < board.length; i++) {
        	for (int j = 0; j < board[i].length; j++) {
        			board[i][j].draw(g);
        	}
        }
    }
	
	// Clears the board and resets each slot to white to represent a blank board
	public void clearBoard() {
        for (int i = 0; i < board.length; i++) {
        	for (int j = 0; j < board[i].length; j++) {
        		board[i][j] = new Chip(COURT_WIDTH, COURT_HEIGHT, Color.WHITE);
        	}
        }
	}
	
	// Finds the lowest unoccupied slot in a column
	public int findSlot(int x) {
		for (int i = 5; i >= 0; i--) {
			if (board[x][i].getColor().equals(Color.WHITE)) {
				return i;
			}
		}
		return -1;
	}
	
	/**
     * Checks if the added chip at position (x, y) with color c will make four chips
     * of color c in a row.
     *
     * @param x The x coordinate of the added chip
     * @param y The y coordinate of the added chip
     * @param c The color of the added chip
     * @return returns a boolean true if there is four in a row, false if there are not four in a row
     */
	public boolean hasFour(int x, int y, Color c) {
		return fourHorizontal(x, y, c) || fourVertical(x, y, c) || fourForwardDiag(x, y, c) || fourBackDiag(x, y, c);
	}
	
	/**
     * Helper function that checks if the added chip at position (x, y) with color c will make four chips
     * of color c in a row in the horizontal direction.
     *
     * @param x The x coordinate of the added chip
     * @param y The y coordinate of the added chip
     * @param c The color of the added chip
     * @return returns a boolean true if there is four in a row, false if there are not four in a row
     */
	public boolean fourHorizontal(int x, int y, Color c) {
		int countRight = 0;
		for (int i = x + 1; i < 7; i++) {
			if (board[i][y].getColor().equals(c)) {
				countRight++;
			} else {
				break;
			}
		}
		int countLeft = 0;
		for (int i = x - 1; i >= 0; i--) {
			if (board[i][y].getColor().equals(c)) {
				countLeft++;
			} else {
				break;
			}
		}
		int isFour = 1 + countRight + countLeft;
		return isFour == 4;
	}
	
	/**
     * Helper function that checks if the added chip at position (x, y) with color c will make four chips
     * of color c in a row in the vertical direction.
     *
     * @param x The x coordinate of the added chip
     * @param y The y coordinate of the added chip
     * @param c The color of the added chip
     * @return returns a boolean true if there is four in a row, false if there are not four in a row
     */
	public boolean fourVertical(int x, int y, Color c) {
		int countDown = 0;
		for (int i = y + 1; i < 6; i++) {
			if (board[x][i].getColor().equals(c)) {
				countDown++;
			} else {
				break;
			}
		}
		int countUp = 0;
		for (int i = y - 1; i >= 0; i--) {
			if (board[x][i].getColor().equals(c)) {
				countUp++;
			} else {
				break;
			}
		}
		int isFour = 1 + countUp + countDown;
		return isFour == 4;
	}
	
	/**
     * Helper function that checks if the added chip at position (x, y) with color c will make four chips
     * of color c in a row in the forward diagonal direction.
     *
     * @param x The x coordinate of the added chip
     * @param y The y coordinate of the added chip
     * @param c The color of the added chip
     * @return returns a boolean true if there is four in a row, false if there are not four in a row
     */
	public boolean fourForwardDiag(int x, int y, Color c) {
		int countDown = 0;
		int k = y + 1;
		for (int i = x - 1; i >= 0; i--) {
			if (k < 6) {
				if (board[i][k].getColor().equals(c)) {
					countDown++;
					k++;
				} else {
					break;
				}
			}
		}
		int countUp = 0;
		int j = y - 1;
		for (int i = x + 1; i < 7; i++) {
			if (j >= 0) {
				if (board[i][j].getColor().equals(c)) {
					countUp++;
					j--;
				} else {
					break;
				}
			}
		}
		int isFour = 1 + countUp + countDown;
		return isFour == 4;
	}
	
	/**
     * Helper function that checks if the added chip at position (x, y) with color c will make four chips
     * of color c in a row in the backwards diagonal direction.
     *
     * @param x The x coordinate of the added chip
     * @param y The y coordinate of the added chip
     * @param c The color of the added chip
     * @return returns a boolean true if there is four in a row, false if there are not four in a row
     */
	public boolean fourBackDiag(int x, int y, Color c) {
		int countDown = 0;
		int k = y + 1;
		for (int i = x + 1; i < 7; i++) {
			if (k < 6) {
				if (board[i][k].getColor().equals(c)) {
					countDown++;
					k++;
				} else {
					break;
				}
			}
		}
		int countUp = 0;
		int j = y - 1;
		for (int i = x - 1; i >= 0; i--) {
			if (j >= 0) {
				if (board[i][j].getColor().equals(c)) {
					countUp++;
					j--;
				} else {
					break;
				}
			}
		}
		int isFour = 1 + countUp + countDown;
		return isFour == 4;
	}
	
	/**
     * Gets the chip at slot (x, y)
     *
     * @param x The x coordinate of the chip
     * @param y The y coordinate of the chip
     * @return returns the Chip object at slot (x, y)
     */
	public Chip getChip(int x, int y) {
		return board[x][y];
	}
	
	/**
     * Gets an 2D int array that represents the color of each slot.
     * 0 represents a white slot ("empty" slot)
     * 1 represents a Red chip
     * 2 represents a Blue chip
     *
     * @return returns an int[][] that represents the state of the board
     */
	public int[][] getBoardState() {
		int[][] boardState = new int[7][6];
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (board[i][j].getColor().equals(Color.WHITE)) {
					boardState[i][j] = 0;
				} else if (board[i][j].getColor().equals(Color.RED)) {
					boardState[i][j] = 1;
				} else {
					boardState[i][j] = 2;
				}
			}
		}
		return boardState;
	}
	
	/**
     * Sets the board with the int representations of the state of the board. Updates the color of 
     * each slot to its designated state
     *
     * @param boardState An int[][] that contains the int representation of the color of each slot
     */
	public void setBoardState(int[][] boardState) {
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (boardState[i][j] == 0) {
					board[i][j].setColor(Color.WHITE);
				} else if (boardState[i][j] == 1) {
					board[i][j].setColor(Color.RED);
				} else {
					board[i][j].setColor(Color.BLUE);
				}
			}
		}
	}
}
